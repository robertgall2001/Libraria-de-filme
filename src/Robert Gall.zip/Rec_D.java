import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Rec_D extends JDialog{
    private JPanel panel1;
    private JTable table1;
    private JButton inapoiButton;


    public Rec_D(JFrame parent, String us) {
        super(parent);
        setTitle("Recenzii filme disponibile");
        setContentPane(panel1);
        setMinimumSize(new Dimension(700,600));
        setModal(true);
        setLocationRelativeTo(parent);


        Object [][] data = {
                {"TITANIC","Minunat",9,"cristi.gall"}
        };

        table1.setModel(new DefaultTableModel(
                data,
                new String[]{"Titlu","Descriere","Nota","Utilizator"}
        ));

        inapoiButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        setVisible(true);
    }
}
